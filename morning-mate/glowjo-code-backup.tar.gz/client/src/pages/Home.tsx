/**
 * GlowJo — Landing Page
 * Design: Storybook Warmth / Illustrated World
 * Fonts: Fredoka One (display) + Nunito (body)
 * Colors: Sunrise gradient — sky blue → amber → coral
 */
import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663462837813/Q6tJTdg6w67gktwsr4Arms/morning-hero-bg-fhdC9vtNYWmWwWTUt8eFwh.webp";
const SUNNY_MASCOT = "https://d2xsxph8kpxj0f.cloudfront.net/310519663462837813/Q6tJTdg6w67gktwsr4Arms/sunny-mascot-B2aYkz9voMHKCVjDWR9DQM.webp";

// ── DEMO TASKS ──
const DEMO_TASKS = [
  { emoji: "☀️", label: "WAKE UP!", mascot: "😄", speech: "Rise and shine superstar!", voice: "Rise and shine superstar! You got this!", stars: 1 },
  { emoji: "🛁", label: "SHOWER TIME!", mascot: "😊", speech: "So squeaky clean!", voice: "Clean champion coming through! Looking great!", stars: 2 },
  { emoji: "🥛", label: "EAT BREAKFAST!", mascot: "🤩", speech: "Superpowers loaded!", voice: "Fuel up! You are a rocket today!", stars: 3 },
  { emoji: "🪥", label: "BRUSH TEETH!", mascot: "😁", speech: "Dazzling smile!", voice: "Shiniest smile in the whole world! Great job!", stars: 4 },
  { emoji: "🎒", label: "PACK YOUR BAG!", mascot: "🚀", speech: "Ready to fly!", voice: "Zip it up! You are totally ready to fly!", stars: 5 },
  { emoji: "🚀", label: "LET'S GO!", mascot: "🏆", speech: "You are LEGENDARY!", voice: "Daily winner! You are absolutely LEGENDARY!", stars: 6 },
];

// ── CONFETTI ──
function spawnConfetti(container: HTMLElement) {
  const colors = ["#ff5f1f", "#ffd700", "#4facfe", "#ff9a3c", "#ff6b35", "#fff"];
  for (let i = 0; i < 30; i++) {
    const el = document.createElement("div");
    el.style.cssText = `
      position:absolute; width:10px; height:10px; border-radius:2px;
      background:${colors[Math.floor(Math.random() * colors.length)]};
      left:${Math.random() * 100}%; top:0;
      animation: confetti-fall ${1.5 + Math.random() * 1.5}s ease-out forwards;
      animation-delay:${Math.random() * 0.5}s;
      pointer-events:none; z-index:50;
    `;
    container.appendChild(el);
    setTimeout(() => el.remove(), 3500);
  }
}

// ── DEMO COMPONENT ──
function DemoPhone() {
  const [demoIdx, setDemoIdx] = useState(0);
  const [demoDone, setDemoDone] = useState(false);
  const [currentTask, setCurrentTask] = useState(DEMO_TASKS[0]);
  const [mascot, setMascot] = useState("😴");
  const [speech, setSpeech] = useState("Tap to wake me up!");
  const [stars, setStars] = useState("☆☆☆☆☆☆");
  const [hint, setHint] = useState("TAP ME! 👆");
  const [voiceMsg, setVoiceMsg] = useState("");
  const [showVoice, setShowVoice] = useState(false);
  const [pulsing, setPulsing] = useState(true);
  const confettiRef = useRef<HTMLDivElement>(null);
  const voiceTimer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const audioCache = useRef<Record<string, string>>({});
  const ttsMutation = trpc.tts.speak.useMutation();

  async function speak(text: string) {
    const clean = text.replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, "").trim();
    if (!clean) return;
    if (audioCache.current[clean]) {
      new Audio(audioCache.current[clean]).play().catch(() => {});
      return;
    }
    try {
      const ttsResult = await ttsMutation.mutateAsync({ text: clean, language: "en" }).catch(() => null);
      if (ttsResult?.success && ttsResult.audioUrl) {
        audioCache.current[clean] = ttsResult.audioUrl;
        new Audio(ttsResult.audioUrl).play().catch(() => {});
        return;
      }
    } catch (error) {
      console.warn("[TTS] Backend proxy failed, falling back to browser TTS");
    }
    
    try {
      const utterance = new SpeechSynthesisUtterance(clean);
      const voices = window.speechSynthesis.getVoices();
      const femaleVoice = voices.find(v =>
        v.name.includes("Google US English") ||
        v.name.includes("Samantha") ||
        v.name.includes("Female") ||
        v.name.includes("woman")
      ) || voices[1] || voices[0];
      if (femaleVoice) utterance.voice = femaleVoice;
      utterance.rate = 0.85;
      utterance.pitch = 1.2;
      window.speechSynthesis.speak(utterance);
    } catch (e) {
      console.error("[TTS] Browser TTS failed:", e);
    }
  }

  function handleTap() {
    if (demoDone) {
      setDemoIdx(0);
      setDemoDone(false);
      setCurrentTask(DEMO_TASKS[0]);
      setMascot("😴");
      setSpeech("Tap to wake me up!");
      setStars("☆☆☆☆☆☆");
      setHint("TAP ME! 👆");
      setPulsing(true);
      return;
    }

    const task = DEMO_TASKS[demoIdx];
    setCurrentTask(task);
    setMascot(task.mascot);
    setSpeech(task.speech);
    setVoiceMsg(task.voice);
    setShowVoice(true);
    speak(task.voice);

    if (voiceTimer.current) clearTimeout(voiceTimer.current);
    voiceTimer.current = setTimeout(() => setShowVoice(false), 3000);

    const newStars = "⭐".repeat(task.stars) + "☆".repeat(6 - task.stars);
    setStars(newStars);

    if (demoIdx < DEMO_TASKS.length - 1) {
      setDemoIdx(demoIdx + 1);
      setHint("TAP AGAIN! 👆");
    } else {
      setDemoDone(true);
      setHint("YOU DID IT! 🏆");
      setPulsing(false);
      if (confettiRef.current) spawnConfetti(confettiRef.current);
    }
  }

  return (
    <div style={{ marginTop: 48, animation: "float 4s ease-in-out infinite, fadein 1s ease-out 1s both", position: "relative" }}>
      <div
        ref={confettiRef}
        style={{
          width: 220, height: 440,
          background: "linear-gradient(180deg,#4facfe,#ff9a3c,#ff6b35)",
          borderRadius: 36,
          border: "6px solid rgba(255,255,255,0.9)",
          boxShadow: "0 24px 60px rgba(0,0,0,0.25), 0 0 0 1px rgba(255,255,255,0.3)",
          display: "flex", flexDirection: "column", alignItems: "center",
          justifyContent: "center", gap: 8, overflow: "hidden",
          position: "relative",
          cursor: "pointer",
          transition: "transform 0.1s",
        }}
        onClick={handleTap}
      >
        <div style={{ position: "absolute", top: 12, left: "50%", transform: "translateX(-50%)", width: 60, height: 6, background: "rgba(255,255,255,0.5)", borderRadius: 10 }} />
        <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 14, color: "white", opacity: 0.9 }}>GlowJo</div>
        <div style={{ fontSize: 64, animation: "mascot-bounce 1.5s ease-in-out infinite alternate" }}>{mascot}</div>
        <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 13, color: "white", opacity: 0.9, textAlign: "center", maxWidth: "90%" }}>{currentTask.label}</div>
        <div style={{ fontSize: 16, letterSpacing: 2 }}>{stars}</div>
        {showVoice && <div style={{ fontSize: 11, color: "white", fontStyle: "italic", textAlign: "center", maxWidth: "90%", opacity: 0.8 }}>"{voiceMsg}"</div>}
        <div
          style={{
            width: 100, height: 100, borderRadius: "50%",
            background: "rgba(255,95,31,0.3)", border: "4px solid #ff5f1f",
            boxShadow: "0 0 20px rgba(255,95,31,0.5)",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 44,
            animation: pulsing ? "pulse 1s ease-in-out infinite" : "none",
          }}
        >
          👆
        </div>
        <div style={{ fontSize: 12, color: "white", fontWeight: 700, marginTop: 8 }}>{hint}</div>
      </div>
    </div>
  );
}

export default function Home() {
  const [, navigate] = useLocation();
  const [email, setEmail] = useState("");
  const emailMutation = trpc.analytics.captureEmail.useMutation();
  const stripeCheckoutMutation = trpc.stripe.createCheckoutSession.useMutation();

  const handleEmailCapture = async () => {
    if (!email) {
      toast.error("Please enter your email");
      return;
    }
    try {
      await emailMutation.mutateAsync({ email });
      toast.success("Thanks! Check your email for updates.");
      setEmail("");
    } catch (error) {
      toast.error("Failed to capture email");
    }
  };

  const handleCheckout = async (tier: "starter" | "plus" | "gold") => {
    try {
      const session = await stripeCheckoutMutation.mutateAsync({ tier });
      if (session?.checkoutUrl) {
        window.location.href = session.checkoutUrl;
      }
    } catch (error) {
      toast.error("Failed to start checkout");
    }
  };

  useEffect(() => {
    document.querySelectorAll(".reveal").forEach((el) => {
      const observer = new IntersectionObserver((entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) e.target.classList.add("visible");
        });
      }, { threshold: 0.1 });
      observer.observe(el);
    });
  }, []);

  return (
    <div style={{ background: "var(--soft)", color: "var(--dark)", fontFamily: "'Nunito', sans-serif", overflowX: "hidden" }}>
      <style>{`
        :root {
          --sunrise-top:#4facfe;
          --sunrise-mid:#ff9a3c;
          --sunrise-bot:#ff6b35;
          --yellow:#ffd700;
          --coral:#ff5f1f;
          --cream:#fff8ee;
          --dark:#2d1a00;
          --mid:#6b3a00;
          --soft:#fff3e0;
        }
        @keyframes flyout{0%{transform:translate(0,0)scale(1);opacity:1}100%{transform:translate(var(--tx),var(--ty))scale(0.2);opacity:0}}
        @keyframes cfall{0%{transform:translateY(-20px)rotate(0);opacity:1}100%{transform:translateY(120vh)rotate(720deg);opacity:0}}
        @keyframes mascot-bounce { from{transform:scale(1)} to{transform:scale(1.1) translateY(-4px)} }
        @keyframes pulse { 0%,100%{box-shadow:0 0 20px rgba(255,95,31,0.5)} 50%{box-shadow:0 0 40px rgba(255,95,31,0.8)} }
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-12px)} }
        @keyframes fadein { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes sun-rise { 0%{transform:translateX(-50%) translateY(60px);opacity:0} 100%{transform:translateX(-50%) translateY(0px);opacity:1} }
        @keyframes drift { from{transform:translateX(-100px)} to{transform:translateX(110vw)} }
        .reveal { opacity:0; }
        .reveal.visible { animation:fadein 0.6s ease-out forwards; }
      `}</style>

      {/* NAV */}
      <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 100, padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", background: "rgba(255,248,238,0.92)", backdropFilter: "blur(12px)", borderBottom: "1px solid rgba(255,154,60,0.2)" }}>
        <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 22, color: "var(--coral)" }}>Glow<span style={{ color: "var(--dark)" }}>Jo</span></div>
        <button onClick={() => navigate("/onboarding")} style={{ fontFamily: "'Fredoka One',cursive", fontSize: 15, padding: "9px 22px", borderRadius: 30, border: "none", cursor: "pointer", background: "linear-gradient(135deg,var(--coral),var(--sunrise-mid))", color: "white", textDecoration: "none", boxShadow: "0 4px 14px rgba(255,95,31,0.35)", transition: "transform 0.15s, box-shadow 0.15s" }}>
          Get Started
        </button>
      </nav>

      {/* HERO */}
      <section style={{ minHeight: "100vh", background: "linear-gradient(180deg, var(--sunrise-top) 0%, var(--sunrise-mid) 60%, var(--sunrise-bot) 100%)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "100px 24px 60px", position: "relative", overflow: "hidden", marginTop: 60 }}>
        <div style={{ position: "absolute", top: -60, left: "50%", transform: "translateX(-50%)", width: 220, height: 220, borderRadius: "50%", background: "radial-gradient(circle, #ffe566 0%, #ffb830 50%, rgba(255,154,60,0) 70%)", animation: "sun-rise 3s ease-out forwards", opacity: 0 }} />
        <div style={{ position: "absolute", fontSize: 56, opacity: 0.18, animation: "drift linear infinite", top: "12%", left: "-60px", animationDuration: "18s", animationDelay: "0s" }}>☁️</div>
        <div style={{ position: "absolute", fontSize: 48, opacity: 0.18, animation: "drift linear infinite", top: "22%", left: "-80px", animationDuration: "24s", animationDelay: "5s" }}>☁️</div>
        <div style={{ position: "absolute", fontSize: 36, opacity: 0.18, animation: "drift linear infinite", top: "8%", left: "-40px", animationDuration: "20s", animationDelay: "10s" }}>☁️</div>

        <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,0.3)", border: "1px solid rgba(255,255,255,0.5)", padding: "6px 16px", borderRadius: 30, fontSize: 13, fontWeight: 700, color: "white", marginBottom: 24, animation: "fadein 0.8s ease-out 0.3s both" }}>
          ⭐ Trusted by 50K+ families
        </div>

        <h1 style={{ fontFamily: "'Fredoka One',cursive", fontSize: "clamp(42px,10vw,80px)", color: "white", lineHeight: 1.1, textShadow: "0 4px 20px rgba(0,0,0,0.15)", animation: "fadein 0.8s ease-out 0.5s both", maxWidth: 800 }}>
          Brush teeth?<em style={{ fontStyle: "normal", color: "var(--yellow)", display: "block" }}>Kids beg to.</em>
        </h1>

        <div style={{ fontSize: "clamp(18px,4vw,24px)", color: "rgba(255,255,255,0.92)", fontWeight: 700, marginTop: 20, maxWidth: 560, lineHeight: 1.5, animation: "fadein 0.8s ease-out 0.7s both" }}>
          Stop being the alarm clock. GlowJo turns chaotic school mornings into a game kids actually want to play.
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: 14, justifyContent: "center", marginTop: 36, animation: "fadein 0.8s ease-out 0.9s both" }}>
          <button onClick={() => navigate("/onboarding")} style={{ fontFamily: "'Fredoka One',cursive", fontSize: 20, padding: "16px 36px", borderRadius: 50, border: "none", cursor: "pointer", background: "white", color: "var(--coral)", boxShadow: "0 6px 24px rgba(0,0,0,0.2)", transition: "transform 0.15s, box-shadow 0.15s", textDecoration: "none", display: "inline-block" }}>
            Try Free
          </button>
          <button onClick={() => navigate("/app")} style={{ fontFamily: "'Fredoka One',cursive", fontSize: 18, padding: "16px 36px", borderRadius: 50, cursor: "pointer", background: "rgba(255,255,255,0.2)", color: "white", border: "2px solid rgba(255,255,255,0.6)", transition: "background 0.15s", textDecoration: "none", display: "inline-block" }}>
            See Demo
          </button>
        </div>

        <div style={{ marginTop: 32, color: "rgba(255,255,255,0.85)", fontSize: 14, fontWeight: 700, animation: "fadein 0.8s ease-out 1.1s both" }}>
          <span style={{ color: "var(--yellow)", fontSize: 16, letterSpacing: 2 }}>★★★★★</span> 4.9/5 from 2,000+ reviews
        </div>

        <DemoPhone />
      </section>

      {/* PAIN SECTION */}
      <section style={{ background: "var(--dark)", color: "var(--cream)", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ display: "inline-block", fontSize: 12, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase", color: "var(--coral)", marginBottom: 12 }}>The Problem</div>
          <h2 className="reveal" style={{ fontFamily: "'Fredoka One',cursive", fontSize: "clamp(30px,6vw,52px)", color: "var(--cream)", lineHeight: 1.2, marginBottom: 16 }}>
            Mornings are chaos.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px,1fr))", gap: 20, marginTop: 40 }}>
            {[
              { icon: "⏰", title: "The Alarm Clock Parent", text: "You're nagging, reminding, and yelling. Kids tune you out." },
              { icon: "😤", title: "Power Struggles", text: "Every task is a battle. Brushing teeth? Forget it." },
              { icon: "🏫", title: "Late to School", text: "Rushing = stress. Stress = kids can't focus all day." },
              { icon: "😰", title: "Cortisol Overload", text: "Chaotic mornings flood kids' brains with stress hormones." },
            ].map((item, i) => (
              <div key={i} className="reveal" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 20, padding: 24, transition: "transform 0.2s" }}>
                <div style={{ fontSize: 36, marginBottom: 12 }}>{item.icon}</div>
                <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 20, color: "var(--yellow)", marginBottom: 8 }}>{item.title}</div>
                <div style={{ fontSize: 15, color: "rgba(255,248,238,0.7)", lineHeight: 1.6 }}>{item.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ background: "var(--soft)", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ display: "inline-block", fontSize: 12, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase", color: "var(--coral)", marginBottom: 12 }}>How It Works</div>
          <h2 className="reveal" style={{ fontFamily: "'Fredoka One',cursive", fontSize: "clamp(30px,6vw,52px)", color: "var(--dark)", lineHeight: 1.2, marginBottom: 16 }}>
            3 steps to peaceful mornings.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 32, marginTop: 48 }}>
            {[
              { num: "1", emoji: "📱", title: "Download", text: "Free app for iOS & Android. No account needed." },
              { num: "2", emoji: "🎮", title: "Set Up Tasks", text: "Choose 3–6 morning tasks. Kids see fun emojis, not chores." },
              { num: "3", emoji: "⭐", title: "Earn Stars", text: "Each task = stars. Streaks = rewards. Kids love it." },
            ].map((step, i) => (
              <div key={i} className="reveal" style={{ textAlign: "center", animation: `fadein 0.6s ease-out both`, animationDelay: `${0.1 + i * 0.1}s` }}>
                <div style={{ width: 56, height: 56, borderRadius: "50%", background: "linear-gradient(135deg,var(--coral),var(--sunrise-mid))", color: "white", fontFamily: "'Fredoka One',cursive", fontSize: 24, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", boxShadow: "0 6px 20px rgba(255,95,31,0.3)" }}>
                  {step.num}
                </div>
                <div style={{ fontSize: 48, marginBottom: 12 }}>{step.emoji}</div>
                <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 22, color: "var(--dark)", marginBottom: 8 }}>{step.title}</div>
                <div style={{ fontSize: 15, color: "var(--mid)", lineHeight: 1.6 }}>{step.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section style={{ background: "linear-gradient(180deg,var(--sunrise-top) 0%,var(--sunrise-mid) 100%)", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ display: "inline-block", fontSize: 12, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase", color: "var(--yellow)", marginBottom: 12 }}>Features</div>
          <h2 style={{ fontFamily: "'Fredoka One',cursive", fontSize: "clamp(30px,6vw,52px)", color: "white", lineHeight: 1.2, marginBottom: 16 }}>
            Packed with what families need.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 20, marginTop: 40 }}>
            {[
              { icon: "🎤", title: "AI Voice", text: "Sunny's warm, encouraging voice guides every task.", badge: "STARTER+" },
              { icon: "🌍", title: "Bilingual", text: "English + Spanish. Perfect for multilingual families.", badge: "STARTER+" },
              { icon: "🔒", title: "Parent Dashboard", text: "PIN-protected parent view with progress tracking.", badge: "FREE" },
              { icon: "📊", title: "Brain Power Reports", text: "Weekly PDF reports showing Executive Function growth.", badge: "PLUS+" },
              { icon: "🏆", title: "Brain Boss Certificate", text: "When kids hit 500 stars, unlock a printable Certificate.", badge: "PLUS+" },
              { icon: "📱", title: "Offline Mode", text: "Works without WiFi. Perfect for car rides & travel.", badge: "FREE" },
            ].map((feat, i) => (
              <div key={i} className="reveal" style={{ background: "rgba(255,255,255,0.18)", border: "1px solid rgba(255,255,255,0.3)", borderRadius: 20, padding: 24, backdropFilter: "blur(8px)", transition: "transform 0.2s" }}>
                <div style={{ fontSize: 32, marginBottom: 12 }}>{feat.icon}</div>
                <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 18, color: "white", marginBottom: 8 }}>{feat.title}</div>
                <div style={{ fontSize: 15, color: "rgba(255,255,255,0.85)", lineHeight: 1.6, marginBottom: 12 }}>{feat.text}</div>
                <div style={{ fontSize: 11, fontWeight: 900, padding: "4px 12px", borderRadius: 20, background: feat.badge.includes("FREE") ? "rgba(255,255,255,0.2)" : "var(--yellow)", color: feat.badge.includes("FREE") ? "white" : "var(--dark)", display: "inline-block" }}>
                  {feat.badge}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section style={{ background: "var(--soft)", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto", textAlign: "center" }}>
          <div style={{ display: "inline-block", fontSize: 12, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase", color: "var(--coral)", marginBottom: 12 }}>Testimonials</div>
          <h2 className="reveal" style={{ fontFamily: "'Fredoka One',cursive", fontSize: "clamp(30px,6vw,52px)", color: "var(--dark)", lineHeight: 1.2, marginBottom: 16 }}>
            Parents love it.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px,1fr))", gap: 24, marginTop: 40 }}>
            {[
              { text: "We went from 45 minutes of screaming to 15 minutes of happy. The voice feature is MAGIC.", author: "Maria G., Mom · Orlando, FL", stars: 5 },
              { text: "As a teacher, I recommend this to every parent. The executive function benefits are real.", author: "Ms. Johnson, VPK Teacher · Tampa, FL", stars: 5 },
              { text: "Mi hijo ahora hace todo solo. The bilingual mode is perfect for our home.", author: "Ana R., Mamá · Fort Lauderdale, FL", stars: 5 },
              { text: "My twins were racing each other to finish their tasks after day 1. Worth every penny.", author: "Jennifer K., Mom of twins · Jacksonville, FL", stars: 5 },
              { text: "The streak feature is genius. My son hasn't broken his 23-day streak and he's SO proud.", author: "David L., Dad · Atlanta, GA", stars: 5 },
              { text: "School mornings are peaceful now. I actually enjoy mornings with my kids!", author: "Sarah M., Mom · Miami, FL", stars: 5 },
            ].map((t, i) => (
              <div key={i} className="reveal" style={{ background: "#fff3e0", borderRadius: 20, padding: 28, borderLeft: "4px solid #ff5f1f", position: "relative" }}>
                <div style={{ color: "var(--yellow)", fontSize: 14, marginBottom: 8 }}>{"★".repeat(t.stars)}</div>
                <p style={{ fontSize: 16, color: "var(--dark)", lineHeight: 1.7, fontStyle: "italic", marginBottom: 16, position: "relative", zIndex: 1 }}>
                  "{t.text}"
                </p>
                <div style={{ fontWeight: 900, color: "var(--coral)", fontSize: 14 }}>{t.author}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section style={{ background: "var(--soft)", padding: "80px 24px" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto", textAlign: "center" }}>
          <div style={{ display: "inline-block", fontSize: 12, fontWeight: 900, letterSpacing: 2, textTransform: "uppercase", color: "var(--coral)", marginBottom: 12 }}>Pricing</div>
          <h2 className="reveal" style={{ fontFamily: "'Fredoka One',cursive", fontSize: "clamp(30px,6vw,52px)", color: "var(--dark)", lineHeight: 1.2, marginBottom: 16 }}>
            Start free. Upgrade when ready.
          </h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px,1fr))", gap: 24, marginTop: 40 }}>
            {[
              { name: "Freemium", price: "$0", features: ["1 child", "3 core tasks", "Text labels", "Basic tracking"], cta: "Get Started", ctaStyle: { background: "linear-gradient(135deg,var(--coral),var(--sunrise-mid))", color: "white" } },
              { name: "Starter", price: "$2.99/mo", features: ["1 child", "All 6 tasks", "AI voice (Sunny)", "Bilingual EN/ES", "Parent dashboard"], cta: "Start Free Trial", ctaStyle: { background: "linear-gradient(135deg,var(--coral),var(--sunrise-mid))", color: "white", fontSize: 16 } },
              { name: "Plus", price: "$7.99/mo", features: ["2 children", "All Starter features", "Mom's Voice Mode", "Weekend routines", "Full dashboard"], cta: "Start Free Trial", ctaStyle: { background: "linear-gradient(135deg,var(--coral),var(--sunrise-mid))", color: "white" } },
              { name: "Gold", price: "$12.99/mo", features: ["4 children", "All Plus features", "PDF reports", "Brain Boss Cert", "Priority support"], cta: "Start Free Trial", ctaStyle: { background: "linear-gradient(135deg,var(--coral),var(--sunrise-mid))", color: "white" } },
            ].map((tier, i) => (
              <div key={i} className="reveal" style={{ background: "white", borderRadius: 20, padding: 32, boxShadow: "0 8px 24px rgba(0,0,0,0.08)", border: i === 2 ? "3px solid var(--coral)" : "1px solid rgba(0,0,0,0.08)", position: "relative", transition: "transform 0.2s" }}>
                {i === 2 && <div style={{ position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", background: "var(--coral)", color: "white", padding: "4px 16px", borderRadius: 20, fontSize: 12, fontWeight: 900 }}>MOST POPULAR</div>}
                <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 24, color: "var(--dark)", marginBottom: 8 }}>{tier.name}</div>
                <div style={{ fontSize: 32, fontWeight: 900, color: "var(--coral)", marginBottom: 24 }}>{tier.price}</div>
                <ul style={{ textAlign: "left", marginBottom: 24, listStyle: "none" }}>
                  {tier.features.map((f, j) => (
                    <li key={j} style={{ fontSize: 14, color: "var(--mid)", marginBottom: 8, paddingLeft: 20, position: "relative" }}>
                      <span style={{ position: "absolute", left: 0 }}>✓</span> {f}
                    </li>
                  ))}
                </ul>
                <button onClick={() => handleCheckout(tier.name.toLowerCase() as "starter" | "plus" | "gold")} style={{ width: "100%", padding: "12px 24px", borderRadius: 30, border: "none", cursor: "pointer", fontFamily: "'Fredoka One',cursive", fontSize: 16, fontWeight: 900, ...tier.ctaStyle, transition: "transform 0.15s" }}>
                  {tier.cta}
                </button>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 32, fontSize: 14, color: "var(--mid)" }}>
            No credit card required • Cancel anytime • 7-day free trial
          </div>
        </div>
      </section>

      {/* EMAIL CAPTURE */}
      <section style={{ background: "linear-gradient(135deg,var(--coral),var(--sunrise-mid))", padding: "80px 24px", textAlign: "center" }}>
        <div style={{ maxWidth: 600, margin: "0 auto" }}>
          <h2 style={{ fontFamily: "'Fredoka One',cursive", fontSize: "clamp(28px,5vw,44px)", color: "white", lineHeight: 1.2, marginBottom: 16 }}>
            Join 50K+ families
          </h2>
          <p style={{ fontSize: 18, color: "rgba(255,255,255,0.9)", marginBottom: 24 }}>
            Get tips, updates, and exclusive offers delivered to your inbox.
          </p>
          <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
            <input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              style={{ flex: 1, padding: "12px 16px", borderRadius: 30, border: "none", fontSize: 14, fontFamily: "'Nunito', sans-serif" }}
            />
            <button onClick={handleEmailCapture} style={{ padding: "12px 28px", borderRadius: 30, border: "none", background: "white", color: "var(--coral)", fontFamily: "'Fredoka One',cursive", fontWeight: 900, cursor: "pointer", transition: "transform 0.15s" }}>
              Join
            </button>
          </div>
          <p style={{ fontSize: 12, color: "rgba(255,255,255,0.7)" }}>We respect your privacy. Unsubscribe anytime.</p>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ background: "var(--dark)", color: "var(--cream)", padding: "40px 24px", textAlign: "center" }}>
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ fontFamily: "'Fredoka One',cursive", fontSize: 20, color: "var(--coral)", marginBottom: 16 }}>Glow<span style={{ color: "var(--cream)" }}>Jo</span></div>
          <p style={{ fontSize: 14, color: "rgba(255,248,238,0.6)", marginBottom: 16 }}>
            Turning chaotic mornings into peaceful routines, one star at a time.
          </p>
          <div style={{ fontSize: 12, color: "rgba(255,248,238,0.4)" }}>
            © 2026 GlowJo. All rights reserved. | Privacy Policy | Terms of Service
          </div>
        </div>
      </footer>
    </div>
  );
}
