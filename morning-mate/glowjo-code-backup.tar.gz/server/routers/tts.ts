import { z } from "zod";
import { publicProcedure, router } from "../_core/trpc";

/**
 * Text-to-Speech proxy using Google Cloud TTS API
 * Google Cloud has superior female voice quality and naturalness
 * Keeps API key secure on backend, prevents client-side credential exposure
 */

export const ttsRouter = router({
  /**
   * Generate speech audio from text
   * Returns audio URL that can be played in browser
   */
  speak: publicProcedure
    .input(
      z.object({
        text: z.string().min(1).max(500),
        language: z.enum(["en", "es"]).default("en"),
      })
    )
    .mutation(async ({ input }) => {
      const apiKey = process.env.BUILT_IN_FORGE_API_KEY;
      const apiUrl = process.env.BUILT_IN_FORGE_API_URL;
      
      if (!apiKey || !apiUrl) {
        console.warn("[TTS] Google Cloud TTS API key not configured");
        return { success: false, error: "TTS not configured" };
      }

      // Clean text (remove emojis)
      const cleanText = input.text
        .replace(/([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g, "")
        .trim();

      if (!cleanText) {
        return { success: false, error: "No valid text to speak" };
      }

      try {
        // Use Google Cloud Text-to-Speech with warm female voice
        // Voice: en-US-Neural2-C (warm, natural female voice)
        // For Spanish: es-ES-Neural2-C (warm female)
        const voiceMap: Record<string, { languageCode: string; name: string }> = {
          en: { languageCode: "en-US", name: "en-US-Neural2-C" }, // Warm female voice
          es: { languageCode: "es-ES", name: "es-ES-Neural2-C" }, // Warm female voice
        };

        const voice = voiceMap[input.language] || voiceMap["en"];

        const response = await fetch(`${apiUrl}/tts`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${apiKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            text: cleanText,
            voice: {
              languageCode: voice.languageCode,
              name: voice.name,
            },
            audioConfig: {
              audioEncoding: "MP3",
              pitch: 0.5, // Slightly higher pitch for warmth
              speakingRate: 0.95, // Slightly slower for clarity
            },
          }),
        });

        if (!response.ok) {
          const errorText = await response.text();
          console.error("[TTS] Google Cloud error:", response.status, errorText);
          return { success: false, error: "TTS generation failed" };
        }

        const data = await response.json() as { audioContent?: string };
        if (!data.audioContent) {
          console.error("[TTS] No audio content in response");
          return { success: false, error: "TTS generation failed" };
        }

        // Convert base64 to data URL
        const audioUrl = `data:audio/mpeg;base64,${data.audioContent}`;

        console.log(`[TTS] Generated warm female voice using Google Cloud TTS (${cleanText.length} chars)`);
        console.log(`[TTS] Voice: ${voice.name}, Speaking rate: 0.95x, Pitch: +0.5`);

        return {
          success: true,
          audioUrl,
        };
      } catch (error) {
        console.error("[TTS] Error:", error);
        return { success: false, error: "TTS generation failed" };
      }
    }),
});
